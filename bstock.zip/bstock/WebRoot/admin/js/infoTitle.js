function PageTitle(MainTitleText)
	{ 
	   var MainTitle = window.parent.document.getElementById("MainTitle");
	   MainTitle.innerHTML = MainTitleText;	    
	}